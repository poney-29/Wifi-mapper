# FLOOR-PLAN IMPORT EDITION — ANDROID SOURCE, NOT APK
This is a standalone import-focused Android project, not a patch requiring the earlier ZIP. It includes floor-plan import, calibration, manual wall tracing, step-based path overlays, all-radio Wi-Fi measurement overlays, and self-contained session import/export.
It does NOT retain every feature of the earlier MAX concept (no interpolated heatmap, CSV/PNG export, per-radio display filter, or heading-sensor fallback in this edition).
Generated source, not compiled or phone-tested.

## Import formats
Import plan: PNG, JPG/JPEG, PDF. Uses Android's document picker. For PDF, enter a page number. Selected PDF page is rendered into an image; PDF vector wall data is NOT extracted.
Pick a saved screenshot of an online map, or a downloaded floor-plan image/PDF. No automatic address lookup, public blueprint search, CAD/DWG/DXF, GeoTIFF, shapefile, online map layer, or GIS georeferencing.
Images must be <=25 MB and are downsampled to <=2048 pixels on the longest side. PDF render longest side <=2048. JPEG EXIF orientation is not separately applied: use a correctly oriented screenshot or PNG if needed.
Opening/importing a different plan clears old calibration/walls/survey ONLY after confirmation.
Use trusted PDFs; this prototype uses platform PdfRenderer in the app process, not an isolated renderer service. Password-protected/malformed files may fail.

## Setup on phone after installation
1. Import plan; choose one PDF page if applicable.
2. Press Touch until 'set scale'. Tap endpoints of a known distance; enter meters.
3. Touch 'set position': tap where you are standing.
4. Hold phone FLAT, screen up, top forward. Touch 'set facing' and tap farther ahead in that same physical direction on the drawing.
5. Optional: Touch 'trace walls'; tap pairs of wall endpoints. Leave DOORWAYS OPEN as gaps. Magenta wall segments are manual geometry.
6. Press Start. Allow precise location and Physical activity permissions, enable Wi-Fi and Location services.
7. The cyan path estimates steps, and all visible access points are sampled when fresh scans arrive. The imported drawing stays under the overlays.
8. Pause before editing. Pan mode drags; pinch zoom works in every touch mode. Fit resets view.
9. Export session saves JSON including a PNG copy of the plan, walls, scale, route and samples. Open session restores this file on another installation.

## Wall constraints and route limits
Traced walls are only straight segments; proposed step segments that strictly cross a wall PAUSE recording and ask you to correct position/facing or wall geometry. They do not magically snap you onto the correct corridor. Exact endpoint touches / collinear motion are not robust collision detection. Leave genuine doors open. Background plan pixels alone do not constrain movement until you trace walls.
No automatic wall extraction, route planning, destination search or shortest-path navigation. The path is where the phone estimates you walked, not a computed navigation route.
Step length defaults to 0.70 m; Step length adjusts future movement. Phone step/rotation sensors are required for automatic walking. No camera/GPS/radio-based position correction.
Sensors and step length drift. Correct position and facing at known landmarks. Not for emergency use, accurate measurements or navigation.

## Saving and permissions
Private session autosaves every 10 seconds during recording and on pause/edits. Imports/export may include surrounding network names and BSSIDs: protect them.
No Internet, camera, broad storage, password recovery or packet-capture permission. Uses Android file picker, not filesystem-wide access.
Any file picker/backgrounding pauses collection. Reload restores the map but requires confirming position/facing. Start/resume creates a new route segment; no movement is tracked while paused.
Scan requests ~35 s, manual internals spaced >=31 s; Android may throttle/delay. Only new scans <=15 s old and after start/resume are sampled. Each reading is placed at the latest estimated route position at/before its scan time.
Limits: 15,000 route fixes, 30,000 radio samples, 3,000 walls. Display draws latest 2,000 samples. Import session limit 45 MB. Large image-containing exports and local saves may be slow on low-end phones.
Session format is floorplan-wifi-v1. Earlier MAX JSON is NOT compatible because its coordinates are different. No silent conversion.

## Build
Requires JDK 17, Android SDK platform 35/build tools 35.0.0, Gradle 8.11.1.
No Gradle wrapper JAR bundled. With Gradle 8.11.1 installed, from project root:
 gradle wrapper --gradle-version 8.11.1
Then open folder in Android Studio and sync, or run:
 ./gradlew assembleDebug
Windows: gradlew.bat assembleDebug
Use ANDROID_HOME or local.properties sdk.dir for Android SDK.
APK output: app/build/outputs/apk/debug/app-debug.apk
Transfer APK to phone; allow that particular install source when prompted. No built APK is provided.
An optional GitHub Actions workflow is included. Put project CONTENTS at repository ROOT, then manually run Build APK in Actions. It has not been run; builds may need fixes. GitHub account/network required; check Actions limits/costs. Simply uploading ZIP without extracting project will not work.

## Sources
https://developer.android.com/training/data-storage/shared/documents-files
https://developer.android.com/reference/android/graphics/pdf/PdfRenderer
https://developer.android.com/develop/connectivity/wifi/wifi-scan
